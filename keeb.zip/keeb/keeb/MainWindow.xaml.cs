﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace keeb
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string thing = "";
        public Button[] buttarray = new Button[24];
        public string[] alpha = new string[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x" };
        public string[] beta = new string[] {"x", "w", "v", "u", "t", "s", "r", "q", "p", "o", "n", "m", "l", "k", "j", "i", "h", "g", "f", "e", "d", "c", "b", "a"};
        public MainWindow()
        {
            InitializeComponent();
            btnGen();
        }

        private void btnGen()
        {
            int count = 0;
            int topmarg = 160;

            for (int x = 0; x < 4; x++)
            {
                int leftmarg = 252;
                for (int y = 0; y < 6; y++)
                {
                    Button butt = new Button();

                    butt.Width = 224;
                    butt.Height = 60;
                    butt.Opacity = .7;
                    butt.Margin = new Thickness(leftmarg, topmarg, 0, 0);
                    butt.VerticalAlignment = VerticalAlignment.Top;
                    butt.HorizontalAlignment = HorizontalAlignment.Left;
                    butt.Name = alpha[count];
                    butt.Content = alpha[count];
                    buttarray[count] = butt;



                    theGrid.Children.Add(butt);
                    leftmarg += 229;
                    count++;
                }
                topmarg += 65;
            }

        }


        private void txt_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (change.Content.Equals("1"))
            {
                if (txt.Text == "")
                    ENIGMA.Text = "";
                for (int x = 0; x < 24; x++)
                {
                    buttarray[x].Background = Brushes.LightGray;

                }
                if (txt.Text != "")
                    thing = txt.Text.Substring(txt.Text.Length - 1, 1);

                if (thing != " " && thing != "")
                {
                    for (int x = 0; x < 24; x++)
                    {
                        if (buttarray[x].Content.ToString().Equals(thing))
                        {
                            buttarray[x].Background = Brushes.LightGreen;
                            ENIGMA.Text += beta[x].ToString();
                            for (int y = 0; y < 24; y++)
                            {
                                if (buttarray[y].Content.ToString().Equals(beta[x].ToString()))
                                {
                                    buttarray[y].Background = Brushes.PaleVioletRed;
                                    into.Content = thing + " turns into " + beta[x];
                                }
                            }
                        }
                    }
                }
                else if(thing == " ")
                {
                    ENIGMA.Text += " ";
                }
            }
        }

        private void button_Click(object sender, EventArgs e)
        {

        }

        private void txt_TextChanged2(object sender, TextChangedEventArgs e)
        {
            if (change.Content.Equals("0"))
            {
                txt.Text = "";
                    string str = ENIGMA.Text.ToString();

                    // Creating array of string length 
                    char[] ch = new char[str.Length];

                    // Copy character by character into array 
                    for (int i = 0; i < str.Length; i++)
                    {
                        ch[i] = str[i];
                    }

                    // Printing content of array 
                    foreach (char c in ch)
                    {
                    if (c != ' ')
                        {
                            for (int y = 0; y < 24; y++)
                            {
                                if (c.ToString().Equals(beta[y]))
                                {
                                    txt.Text += alpha[y] + "";
                                }
                            }
                        }
                        else if (c == ' ')
                        {
                            txt.Text += ' ';
                        }
                    }
                
            }
        }

        private void change_Click(object sender, RoutedEventArgs e)
        {
            if (change.Content.Equals("1"))
            {
                change.Content = "0";
                ENIGMA.Text = "";
                txt.Text = "";
            }
            else
            {
                change.Content = "1";
                ENIGMA.Text = "";
                txt.Text = "";
            }

        }
    }
}
